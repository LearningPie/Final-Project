package com.cdac.LearningPie.Services;

import java.util.List;

import com.cdac.LearningPie.entity.Files;

public interface FileService {

	public void uploadFile(int i, String fileName);

//	public List<Files> getAll();

	

}
