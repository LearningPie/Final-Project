import axios from "axios";
import { useState } from "react";

export default function UploadPdf() {
  const [selectedFile, setSelectedFile] = useState();
  const upload = async () => {
    const data = new FormData();
    data.append("profilePic", selectedFile);
    const response = await axios.post(
      `http://localhost:8080/upload-profile-pic`,
      data
    );
  };
  return (
    <div>
      <form onSubmit={upload}>
        <input type="file" onChange={(e) => setSelectedFile(e.target.value)} />
        <button className="btn btn-warning">Upload</button>
      </form>
    </div>
  );
}
