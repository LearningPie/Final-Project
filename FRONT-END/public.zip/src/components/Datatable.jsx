import Dataset from "./Dataset";

export default function Datatable() {
  return (
    <h1>
      <Dataset />
    </h1>
  );
}
